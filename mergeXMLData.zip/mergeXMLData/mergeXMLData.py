# -*- coding: utf-8 -*-
import os
from lxml import etree as ET

os.chdir(u'C:/Users/A_Libenko/Pictures/mich/test_megre/test') #переходим в директорию с распакованными КПТ
mainDir=os.getcwd() #принимаем текущий путь
objcts=os.listdir(mainDir) #принимаем список объектов в папке
print(objcts) #выводим список КПТ, можно удалить

targetXML=ET.parse(u'C:/Users/A_Libenko/Pictures/mich/test_megre/clearup/kpt 010108.xml') #парсим выходной хмл
targetBlock=targetXML.find('.//cadastral_blocks') #находим в выходном раздел с кварталами


for elem in objcts: #для каждой КПТ в директории с кпт
    srcXML=ET.parse(elem) #распарсить исходную кпт
    srcBlock=srcXML.find('.//cadastral_block') #находим квартал
    targetBlock.append(srcBlock) #добавляем найденный квартал 

ET.ElementTree(targetBlock).write(u'C:/Users/A_Libenko/Pictures/mich/test_megre/clearup/kpt 010108.xml', pretty_print=True, encoding='utf-8', xml_declaration=True)    #перезаписываем файлы